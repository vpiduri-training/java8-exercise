package com.example.java8;

public class JoinerMethod {

	public static void main(String[] args) {

	}		
}
